# Modified by Modular RAG Engine: text-evaluation-no-resource-loading-no-diskcache-v1
import functools
import hashlib
import inspect
import json
import logging
import sys
from abc import ABC, abstractmethod
from typing import Any, Optional

from pydantic import BaseModel, GetCoreSchemaHandler
from pydantic_core import CoreSchema, core_schema

logger = logging.getLogger(__name__)


class CacheInterface(ABC):
    """Abstract base class defining the interface for cache implementations.

    This class provides a standard interface that all cache implementations must follow.
    It supports basic cache operations like get, set and key checking.
    """

    @abstractmethod
    def get(self, key: str) -> Any:
        """Retrieve a value from the cache by key.

        Args:
            key: The key to look up in the cache.

        Returns:
            The cached value associated with the key.
        """
        pass

    @abstractmethod
    def set(self, key: str, value) -> None:
        """Store a value in the cache with the given key.

        Args:
            key: The key to store the value under.
            value: The value to cache.
        """
        pass

    @abstractmethod
    def has_key(self, key: str) -> bool:
        """Check if a key exists in the cache.

        Args:
            key: The key to check for.

        Returns:
            True if the key exists in the cache, False otherwise.
        """
        pass

    @classmethod
    def __get_pydantic_core_schema__(
        cls, source_type: Any, handler: GetCoreSchemaHandler
    ) -> CoreSchema:
        """
        Define how Pydantic generates a schema for BaseRagasEmbeddings.
        """
        return core_schema.no_info_after_validator_function(
            cls,
            core_schema.is_instance_schema(cls),  # The validator function
        )


class DiskCacheBackend(CacheInterface):
    """Project patch: persistent pickle caching is not included in this build."""
    def __init__(self, *args, **kwargs):
        raise RuntimeError("DiskCache is disabled in this text-evaluation build")
    def get(self, key):
        raise RuntimeError("DiskCache is disabled")
    def set(self, key, value):
        raise RuntimeError("DiskCache is disabled")
    def has_key(self, key):
        raise RuntimeError("DiskCache is disabled")


def _make_hashable(o):
    if isinstance(o, (tuple, list)):
        return tuple(_make_hashable(e) for e in o)
    elif isinstance(o, dict):
        return tuple(sorted((k, _make_hashable(v)) for k, v in o.items()))
    elif isinstance(o, set):
        return tuple(sorted(_make_hashable(e) for e in o))
    elif isinstance(o, BaseModel):
        return _make_hashable(o.model_dump())
    else:
        return o


EXCLUDE_KEYS = ["callbacks"]


def _make_pydantic_picklable(obj: Any) -> Any:
    """Make Pydantic models returned by instructor library picklable.

    The instructor library dynamically creates new class objects during structured
    output generation. These modified classes have class identity issues that prevent
    pickling. This function detects such instances and recreates them using the
    original class from the module namespace.

    Args:
        obj: Object to make picklable (typically a Pydantic model instance).

    Returns:
        A picklable version of the object. For Pydantic models with class identity
        issues, returns a new instance created with the correct class. Otherwise,
        returns the original object unchanged.
    """
    if isinstance(obj, BaseModel):
        obj_class = obj.__class__
        module = sys.modules.get(obj_class.__module__)

        if module is not None:
            actual_class = getattr(module, obj_class.__name__, None)

            if actual_class is not None and actual_class is not obj_class:
                logger.debug(
                    f"Detected class identity mismatch for {obj_class.__name__}, "
                    f"recreating with actual class from module"
                )
                return actual_class(**obj.model_dump())

    return obj


def _generate_cache_key(func, args, kwargs):
    filtered_kwargs = {k: v for k, v in kwargs.items() if k not in EXCLUDE_KEYS}

    key_data = {
        "function": func.__qualname__,
        "args": _make_hashable(args),
        "kwargs": _make_hashable(filtered_kwargs),
    }

    key_string = json.dumps(key_data, sort_keys=True, default=str)
    cache_key = hashlib.sha256(key_string.encode("utf-8")).hexdigest()
    return cache_key


def cacher(cache_backend: Optional[CacheInterface] = None):
    """Decorator that adds caching functionality to a function.

    This decorator can be applied to both synchronous and asynchronous functions to cache their results.
    If no cache backend is provided, the original function is returned unchanged.

    Args:
        cache_backend (Optional[CacheInterface]): The cache backend to use for storing results.
            If None, caching is disabled.

    Returns:
        Callable: A decorated function that implements caching behavior.
    """

    def decorator(func):
        if cache_backend is None:
            return func

        # hack to make pyright happy
        backend: CacheInterface = cache_backend

        is_async = inspect.iscoroutinefunction(func)

        @functools.wraps(func)
        async def async_wrapper(*args, **kwargs):
            cache_key = _generate_cache_key(func, args, kwargs)

            if backend.has_key(cache_key):
                logger.debug(f"Cache hit for {cache_key}")
                return backend.get(cache_key)

            result = await func(*args, **kwargs)
            picklable_result = _make_pydantic_picklable(result)
            backend.set(cache_key, picklable_result)
            return result

        @functools.wraps(func)
        def sync_wrapper(*args, **kwargs):
            cache_key = _generate_cache_key(func, args, kwargs)

            if backend.has_key(cache_key):
                logger.debug(f"Cache hit for {cache_key}")
                return backend.get(cache_key)

            result = func(*args, **kwargs)
            picklable_result = _make_pydantic_picklable(result)
            backend.set(cache_key, picklable_result)
            return result

        return async_wrapper if is_async else sync_wrapper

    return decorator
